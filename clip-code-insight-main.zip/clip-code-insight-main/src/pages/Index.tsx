
import React from "react";
import ClipboardParser from "../components/ClipboardParser";

const Index = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <ClipboardParser />
    </div>
  );
};

export default Index;
